
public class Queue<T> implements QueueADT<T> {
	LinkedList<T> Queue;
	public Queue() {
		Queue = new LinkedList<T>();
	}
	public boolean isEmpty() {
		return Queue.size()==0;
	}

	public void enqueue(T data) throws IllegalArgumentException {
		if (data == null) {
			throw new IllegalArgumentException();
		}
		Queue.add(data);		
	}

	public T dequeue() {
		T removed = Queue.remove(0);
		return removed;
	}

	public T element() throws EmptyQueueException{
		if (Queue.size()==0) {
			throw new EmptyQueueException();
		}
		return Queue.get(0);;
	}

}
