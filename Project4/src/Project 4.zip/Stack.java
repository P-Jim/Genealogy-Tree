import java.util.EmptyStackException;

public class Stack<T> implements StackADT<T> {
	LinkedList<T> Stack;
	public Stack() {
		Stack = new LinkedList<T>();
	}
	public boolean isEmpty() {
		return Stack.size()==0;
	}

	public void push(T data) throws IllegalArgumentException {
		Stack.add(data);		
	}

	public T peek() throws EmptyStackException {
		return Stack.get(Stack.size()-1);
	}

	public T pop() throws EmptyStackException {
		T removed = Stack.remove(Stack.size()-1);
		return removed;
	}

	public StackADT<T> reverse() {
		Stack reverse = new Stack();
		for (int i = Stack.size()-1; i >=0; i--) {
			reverse.push(Stack.get(i));
		}
		return reverse;
	}

}
